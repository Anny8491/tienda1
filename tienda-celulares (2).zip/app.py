from flask import Flask, render_template, request, redirect, url_for, flash, jsonify, session
from flask_sqlalchemy import SQLAlchemy
from flask_login import LoginManager, UserMixin, login_user, login_required, logout_user, current_user
from werkzeug.security import generate_password_hash, check_password_hash
from werkzeug.utils import secure_filename
from datetime import datetime
import os
import requests
from bs4 import BeautifulSoup
import json
import uuid
import re

# Configuración de la aplicación
app = Flask(__name__)
app.config['SECRET_KEY'] = 'clave_secreta_para_la_aplicacion'
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///tienda.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.config['UPLOAD_FOLDER'] = 'static/uploads'
app.config['MAX_CONTENT_LENGTH'] = 16 * 1024 * 1024  # 16MB max-limit

# Asegurar que existe el directorio de uploads
os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)

# Inicializar la base de datos
db = SQLAlchemy(app)

# Configurar el sistema de login
login_manager = LoginManager()
login_manager.init_app(app)
login_manager.login_view = 'login'

# Modelos de la base de datos
class User(UserMixin, db.Model):
    id = db.Column(db.Integer, primary_key=True)
    email = db.Column(db.String(100), unique=True, nullable=False)
    password = db.Column(db.String(200), nullable=False)
    full_name = db.Column(db.String(100), nullable=False)
    is_admin = db.Column(db.Boolean, default=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

class Category(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    slug = db.Column(db.String(100), unique=True, nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    products = db.relationship('Product', backref='category', lazy=True)

    def to_dict(self):
        return {
            'id': self.id,
            'name': self.name,
            'slug': self.slug,
            'created_at': self.created_at.isoformat()
        }

class Product(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(200), nullable=False)
    slug = db.Column(db.String(200), unique=True, nullable=False)
    description = db.Column(db.Text)
    price = db.Column(db.Float, nullable=False)
    stock = db.Column(db.Integer, default=0)
    image_url = db.Column(db.String(500))
    category_id = db.Column(db.Integer, db.ForeignKey('category.id'))
    featured = db.Column(db.Boolean, default=False)
    discount_percentage = db.Column(db.Integer, default=0)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    source = db.Column(db.String(50), default='manual')  # 'manual' o 'alkosto'
    external_id = db.Column(db.String(100))  # ID externo para productos de Alkosto

    def to_dict(self):
        return {
            'id': self.id,
            'name': self.name,
            'slug': self.slug,
            'description': self.description,
            'price': self.price,
            'stock': self.stock,
            'image_url': self.image_url,
            'category_id': self.category_id,
            'category_name': self.category.name if self.category else None,
            'featured': self.featured,
            'discount_percentage': self.discount_percentage,
            'created_at': self.created_at.isoformat(),
            'updated_at': self.updated_at.isoformat(),
            'source': self.source,
            'external_id': self.external_id
        }

# Funciones auxiliares
def generate_slug(text):
    """Genera un slug a partir de un texto"""
    text = text.lower()
    text = re.sub(r'[^\w\s-]', '', text)
    text = re.sub(r'[\s_-]+', '-', text)
    return text.strip('-')

def allowed_file(filename):
    """Verifica si el archivo tiene una extensión permitida"""
    ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg', 'gif'}
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

def save_image(file):
    """Guarda una imagen y devuelve la URL"""
    if file and allowed_file(file.filename):
        filename = secure_filename(file.filename)
        # Generar un nombre único para evitar colisiones
        unique_filename = f"{uuid.uuid4().hex}_{filename}"
        file_path = os.path.join(app.config['UPLOAD_FOLDER'], unique_filename)
        file.save(file_path)
        return f"/static/uploads/{unique_filename}"
    return None

@login_manager.user_loader
def load_user(user_id):
    return User.query.get(int(user_id))

# Rutas de la aplicación
@app.route('/')
def index():
    featured_products = Product.query.filter_by(featured=True).limit(4).all()
    discounted_products = Product.query.filter(Product.discount_percentage > 0).order_by(Product.discount_percentage.desc()).limit(4).all()
    categories = Category.query.all()
    return render_template('index.html', 
                          featured_products=featured_products, 
                          discounted_products=discounted_products,
                          categories=categories)

@app.route('/producto/<slug>')
def product_detail(slug):
    product = Product.query.filter_by(slug=slug).first_or_404()
    related_products = []
    if product.category_id:
        related_products = Product.query.filter_by(category_id=product.category_id).filter(Product.id != product.id).limit(4).all()
    return render_template('product_detail.html', product=product, related_products=related_products)

@app.route('/categoria/<slug>')
def category_detail(slug):
    category = Category.query.filter_by(slug=slug).first_or_404()
    products = Product.query.filter_by(category_id=category.id).all()
    return render_template('category_detail.html', category=category, products=products)

@app.route('/ofertas')
def offers():
    products = Product.query.filter(Product.discount_percentage > 0).order_by(Product.discount_percentage.desc()).all()
    return render_template('offers.html', products=products)

@app.route('/login', methods=['GET', 'POST'])
def login():
    if current_user.is_authenticated:
        return redirect(url_for('index'))
    
    if request.method == 'POST':
        email = request.form.get('email')
        password = request.form.get('password')
        
        user = User.query.filter_by(email=email).first()
        
        if user and check_password_hash(user.password, password):
            login_user(user)
            next_page = request.args.get('next')
            return redirect(next_page or url_for('index'))
        else:
            flash('Correo o contraseña incorrectos', 'danger')
    
    return render_template('login.html')

@app.route('/register', methods=['GET', 'POST'])
def register():
    if current_user.is_authenticated:
        return redirect(url_for('index'))
    
    if request.method == 'POST':
        email = request.form.get('email')
        full_name = request.form.get('full_name')
        password = request.form.get('password')
        
        user_exists = User.query.filter_by(email=email).first()
        
        if user_exists:
            flash('El correo ya está registrado', 'danger')
            return redirect(url_for('register'))
        
        hashed_password = generate_password_hash(password, method='sha256')
        new_user = User(email=email, full_name=full_name, password=hashed_password)
        
        db.session.add(new_user)
        db.session.commit()
        
        flash('Cuenta creada exitosamente. Ahora puedes iniciar sesión.', 'success')
        return redirect(url_for('login'))
    
    return render_template('register.html')

@app.route('/logout')
@login_required
def logout():
    logout_user()
    return redirect(url_for('index'))

# Rutas del panel de administración
@app.route('/admin')
@login_required
def admin_dashboard():
    if not current_user.is_admin:
        flash('No tienes permisos para acceder al panel de administración', 'danger')
        return redirect(url_for('index'))
    
    products_count = Product.query.count()
    categories_count = Category.query.count()
    
    return render_template('admin/dashboard.html', 
                          products_count=products_count,
                          categories_count=categories_count)

@app.route('/admin/productos')
@login_required
def admin_products():
    if not current_user.is_admin:
        return redirect(url_for('index'))
    
    products = Product.query.order_by(Product.created_at.desc()).all()
    return render_template('admin/products.html', products=products)

@app.route('/admin/productos/nuevo', methods=['GET', 'POST'])
@login_required
def admin_new_product():
    if not current_user.is_admin:
        return redirect(url_for('index'))
    
    categories = Category.query.all()
    
    if request.method == 'POST':
        name = request.form.get('name')
        description = request.form.get('description')
        price = float(request.form.get('price'))
        stock = int(request.form.get('stock'))
        category_id = request.form.get('category_id')
        featured = 'featured' in request.form
        discount_percentage = request.form.get('discount_percentage')
        
        # Generar slug
        slug = generate_slug(name)
        
        # Verificar si el slug ya existe
        existing_product = Product.query.filter_by(slug=slug).first()
        if existing_product:
            slug = f"{slug}-{uuid.uuid4().hex[:6]}"
        
        # Procesar imagen
        image_url = None
        if 'image' in request.files:
            image_url = save_image(request.files['image'])
        
        # Crear nuevo producto
        new_product = Product(
            name=name,
            slug=slug,
            description=description,
            price=price,
            stock=stock,
            category_id=category_id if category_id else None,
            featured=featured,
            discount_percentage=int(discount_percentage) if discount_percentage else 0,
            image_url=image_url
        )
        
        db.session.add(new_product)
        db.session.commit()
        
        flash('Producto creado exitosamente', 'success')
        return redirect(url_for('admin_products'))
    
    return render_template('admin/product_form.html', categories=categories, product=None)

@app.route('/admin/productos/<int:id>', methods=['GET', 'POST'])
@login_required
def admin_edit_product(id):
    if not current_user.is_admin:
        return redirect(url_for('index'))
    
    product = Product.query.get_or_404(id)
    categories = Category.query.all()
    
    if request.method == 'POST':
        product.name = request.form.get('name')
        product.description = request.form.get('description')
        product.price = float(request.form.get('price'))
        product.stock = int(request.form.get('stock'))
        product.category_id = request.form.get('category_id') if request.form.get('category_id') else None
        product.featured = 'featured' in request.form
        product.discount_percentage = int(request.form.get('discount_percentage')) if request.form.get('discount_percentage') else 0
        
        # Procesar imagen si se proporciona una nueva
        if 'image' in request.files and request.files['image'].filename:
            image_url = save_image(request.files['image'])
            if image_url:
                product.image_url = image_url
        
        db.session.commit()
        
        flash('Producto actualizado exitosamente', 'success')
        return redirect(url_for('admin_products'))
    
    return render_template('admin/product_form.html', product=product, categories=categories)

@app.route('/admin/productos/eliminar/<int:id>', methods=['POST'])
@login_required
def admin_delete_product(id):
    if not current_user.is_admin:
        return redirect(url_for('index'))
    
    product = Product.query.get_or_404(id)
    db.session.delete(product)
    db.session.commit()
    
    flash('Producto eliminado exitosamente', 'success')
    return redirect(url_for('admin_products'))

@app.route('/admin/categorias')
@login_required
def admin_categories():
    if not current_user.is_admin:
        return redirect(url_for('index'))
    
    categories = Category.query.order_by(Category.name).all()
    return render_template('admin/categories.html', categories=categories)

@app.route('/admin/categorias/nueva', methods=['GET', 'POST'])
@login_required
def admin_new_category():
    if not current_user.is_admin:
        return redirect(url_for('index'))
    
    if request.method == 'POST':
        name = request.form.get('name')
        
        # Generar slug
        slug = generate_slug(name)
        
        # Verificar si el slug ya existe
        existing_category = Category.query.filter_by(slug=slug).first()
        if existing_category:
            slug = f"{slug}-{uuid.uuid4().hex[:6]}"
        
        # Crear nueva categoría
        new_category = Category(name=name, slug=slug)
        
        db.session.add(new_category)
        db.session.commit()
        
        flash('Categoría creada exitosamente', 'success')
        return redirect(url_for('admin_categories'))
    
    return render_template('admin/category_form.html', category=None)

@app.route('/admin/categorias/<int:id>', methods=['GET', 'POST'])
@login_required
def admin_edit_category(id):
    if not current_user.is_admin:
        return redirect(url_for('index'))
    
    category = Category.query.get_or_404(id)
    
    if request.method == 'POST':
        category.name = request.form.get('name')
        
        # Actualizar slug solo si cambió el nombre
        if generate_slug(category.name) != category.slug:
            category.slug = generate_slug(category.name)
            
            # Verificar si el slug ya existe
            existing_category = Category.query.filter(Category.slug == category.slug, Category.id != category.id).first()
            if existing_category:
                category.slug = f"{category.slug}-{uuid.uuid4().hex[:6]}"
        
        db.session.commit()
        
        flash('Categoría actualizada exitosamente', 'success')
        return redirect(url_for('admin_categories'))
    
    return render_template('admin/category_form.html', category=category)

@app.route('/admin/categorias/eliminar/<int:id>', methods=['POST'])
@login_required
def admin_delete_category(id):
    if not current_user.is_admin:
        return redirect(url_for('index'))
    
    category = Category.query.get_or_404(id)
    
    # Verificar si hay productos asociados
    products = Product.query.filter_by(category_id=category.id).all()
    if products:
        for product in products:
            product.category_id = None
    
    db.session.delete(category)
    db.session.commit()
    
    flash('Categoría eliminada exitosamente', 'success')
    return redirect(url_for('admin_categories'))

# API para obtener productos de Alkosto en tiempo real
@app.route('/api/alkosto/search', methods=['GET'])
@login_required
def api_alkosto_search():
    if not current_user.is_admin:
        return jsonify({'error': 'No autorizado'}), 403
    
    query = request.args.get('query', '')
    if not query:
        return jsonify({'error': 'Se requiere un término de búsqueda'}), 400
    
    try:
        # Realizar scraping de Alkosto
        url = f"https://www.alkosto.com/search/?q={query}"
        headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36'
        }
        
        response = requests.get(url, headers=headers)
        soup = BeautifulSoup(response.text, 'html.parser')
        
        products = []
        product_elements = soup.select('.product-item')
        
        for element in product_elements[:10]:  # Limitar a 10 resultados
            try:
                product_url = element.select_one('a.product-item__name')['href']
                product_id = product_url.split('/')[-1]
                name = element.select_one('a.product-item__name').text.strip()
                
                price_element = element.select_one('.product-price__value')
                price = 0
                if price_element:
                    price_text = price_element.text.strip().replace('$', '').replace('.', '')
                    price = float(price_text)
                
                image_element = element.select_one('.product-item__image img')
                image_url = image_element['src'] if image_element and 'src' in image_element.attrs else None
                
                products.append({
                    'external_id': product_id,
                    'name': name,
                    'price': price,
                    'image_url': image_url,
                    'url': f"https://www.alkosto.com{product_url}"
                })
            except Exception as e:
                print(f"Error procesando producto: {e}")
                continue
        
        return jsonify({'products': products})
    
    except Exception as e:
        print(f"Error en la búsqueda de Alkosto: {e}")
        return jsonify({'error': 'Error al buscar productos en Alkosto'}), 500

@app.route('/api/alkosto/import', methods=['POST'])
@login_required
def api_alkosto_import():
    if not current_user.is_admin:
        return jsonify({'error': 'No autorizado'}), 403
    
    data = request.json
    if not data or 'product' not in data:
        return jsonify({'error': 'Datos de producto requeridos'}), 400
    
    product_data = data['product']
    
    try:
        # Verificar si el producto ya existe por external_id
        existing_product = Product.query.filter_by(external_id=product_data['external_id']).first()
        
        if existing_product:
            # Actualizar producto existente
            existing_product.name = product_data['name']
            existing_product.price = product_data['price']
            existing_product.image_url = product_data['image_url']
            existing_product.updated_at = datetime.utcnow()
            
            db.session.commit()
            return jsonify({'success': True, 'message': 'Producto actualizado', 'product_id': existing_product.id})
        else:
            # Crear nuevo producto
            slug = generate_slug(product_data['name'])
            
            # Verificar si el slug ya existe
            slug_exists = Product.query.filter_by(slug=slug).first()
            if slug_exists:
                slug = f"{slug}-{uuid.uuid4().hex[:6]}"
            
            # Asignar categoría (smartphones por defecto)
            smartphone_category = Category.query.filter_by(name='Smartphones').first()
            category_id = smartphone_category.id if smartphone_category else None
            
            new_product = Product(
                name=product_data['name'],
                slug=slug,
                price=product_data['price'],
                image_url=product_data['image_url'],
                stock=10,  # Stock por defecto
                category_id=category_id,
                source='alkosto',
                external_id=product_data['external_id']
            )
            
            db.session.add(new_product)
            db.session.commit()
            
            return jsonify({'success': True, 'message': 'Producto importado', 'product_id': new_product.id})
    
    except Exception as e:
        print(f"Error importando producto: {e}")
        return jsonify({'error': f'Error al importar producto: {str(e)}'}), 500

# API para obtener productos
@app.route('/api/products', methods=['GET'])
def api_products():
    category_id = request.args.get('category_id')
    featured = request.args.get('featured')
    discounted = request.args.get('discounted')
    
    query = Product.query
    
    if category_id:
        query = query.filter_by(category_id=category_id)
    
    if featured and featured.lower() == 'true':
        query = query.filter_by(featured=True)
    
    if discounted and discounted.lower() == 'true':
        query = query.filter(Product.discount_percentage > 0)
    
    products = query.all()
    return jsonify({'products': [product.to_dict() for product in products]})

@app.route('/api/products/<int:id>', methods=['GET'])
def api_product_detail(id):
    product = Product.query.get_or_404(id)
    return jsonify({'product': product.to_dict()})

@app.route('/api/categories', methods=['GET'])
def api_categories():
    categories = Category.query.all()
    return jsonify({'categories': [category.to_dict() for category in categories]})

# Inicializar la base de datos con datos de ejemplo
@app.before_first_request
def create_tables_and_seed_data():
    db.create_all()
    
    # Verificar si ya hay datos
    if User.query.count() == 0:
        # Crear usuario administrador
        admin = User(
            email='admin@example.com',
            password=generate_password_hash('admin123', method='sha256'),
            full_name='Administrador',
            is_admin=True
        )
        db.session.add(admin)
        
        # Crear categorías
        categories = [
            {'name': 'Smartphones', 'slug': 'smartphones'},
            {'name': 'Tablets', 'slug': 'tablets'},
            {'name': 'Accesorios', 'slug': 'accesorios'},
            {'name': 'Smartwatches', 'slug': 'smartwatches'},
            {'name': 'Audio', 'slug': 'audio'}
        ]
        
        for category_data in categories:
            category = Category(name=category_data['name'], slug=category_data['slug'])
            db.session.add(category)
        
        db.session.commit()
        
        # Obtener IDs de categorías
        smartphones = Category.query.filter_by(slug='smartphones').first()
        tablets = Category.query.filter_by(slug='tablets').first()
        accesorios = Category.query.filter_by(slug='accesorios').first()
        
        # Crear productos de ejemplo
        products = [
            {
                'name': 'iPhone 13 Pro Max',
                'slug': 'iphone-13-pro-max',
                'description': 'El iPhone 13 Pro Max es el smartphone más avanzado de Apple con una pantalla Super Retina XDR de 6.7 pulgadas.',
                'price': 4999900,
                'stock': 15,
                'category_id': smartphones.id,
                'featured': True,
                'discount_percentage': 0,
                'image_url': '/static/uploads/iphone13promax.jpg'
            },
            {
                'name': 'Samsung Galaxy S21 Ultra',
                'slug': 'samsung-galaxy-s21-ultra',
                'description': 'El Galaxy S21 Ultra 5G está diseñado para que puedas fotografiar o filmar contenido de calidad profesional sin esfuerzo.',
                'price': 4299900,
                'stock': 10,
                'category_id': smartphones.id,
                'featured': True,
                'discount_percentage': 15,
                'image_url': '/static/uploads/s21ultra.jpg'
            },
            {
                'name': 'iPad Pro 12.9"',
                'slug': 'ipad-pro-12-9',
                'description': 'El iPad Pro incluye el chip M1 de Apple para un rendimiento de siguiente nivel y una batería que dura todo el día.',
                'price': 3999900,
                'stock': 8,
                'category_id': tablets.id,
                'featured': True,
                'discount_percentage': 0,
                'image_url': '/static/uploads/ipadpro.jpg'
            },
            {
                'name': 'AirPods Pro',
                'slug': 'airpods-pro',
                'description': 'Los AirPods Pro son los únicos auriculares intraurales con cancelación activa de ruido que se adaptan continuamente a tu oído.',
                'price': 999900,
                'stock': 20,
                'category_id': accesorios.id,
                'featured': False,
                'discount_percentage': 10,
                'image_url': '/static/uploads/airpodspro.jpg'
            }
        ]
        
        for product_data in products:
            product = Product(**product_data)
            db.session.add(product)
        
        db.session.commit()

if __name__ == '__main__':
    app.run(debug=True)
