"use client"

import { useState, useEffect } from "react"
import Image from "next/image"
import { Search } from "lucide-react"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Skeleton } from "@/components/ui/skeleton"

interface ImageSearchProps {
  onSelectImage: (imageUrl: string) => void
  productName?: string
}

interface ImageResult {
  id: string
  url: string
  alt: string
}

export function ImageSearch({ onSelectImage, productName = "" }: ImageSearchProps) {
  const [query, setQuery] = useState(productName)
  const [images, setImages] = useState<ImageResult[]>([])
  const [isLoading, setIsLoading] = useState(false)
  const [selectedImageUrl, setSelectedImageUrl] = useState<string | null>(null)

  const searchImages = async () => {
    if (!query.trim()) return

    setIsLoading(true)
    try {
      const response = await fetch(`/api/images/search?query=${encodeURIComponent(query)}`)
      const data = await response.json()

      if (data.images) {
        setImages(data.images)
      }
    } catch (error) {
      console.error("Error al buscar imágenes:", error)
    } finally {
      setIsLoading(false)
    }
  }

  useEffect(() => {
    if (productName) {
      searchImages()
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  const handleSelectImage = (imageUrl: string) => {
    setSelectedImageUrl(imageUrl)
    onSelectImage(imageUrl)
  }

  return (
    <div className="space-y-4">
      <div className="flex gap-2">
        <Input
          placeholder="Buscar imágenes..."
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          onKeyDown={(e) => e.key === "Enter" && searchImages()}
        />
        <Button onClick={searchImages} disabled={isLoading}>
          <Search className="h-4 w-4 mr-2" />
          Buscar
        </Button>
      </div>

      {isLoading ? (
        <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
          {[1, 2, 3, 4, 5, 6].map((i) => (
            <Skeleton key={i} className="aspect-square rounded-md" />
          ))}
        </div>
      ) : (
        <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
          {images.map((image) => (
            <Card
              key={image.id}
              className={`cursor-pointer overflow-hidden transition-all ${
                selectedImageUrl === image.url ? "ring-2 ring-blue-500" : ""
              }`}
              onClick={() => handleSelectImage(image.url)}
            >
              <CardContent className="p-0">
                <div className="aspect-square relative">
                  <Image
                    src={image.url || "/placeholder.svg"}
                    alt={image.alt}
                    fill
                    className="object-cover"
                    sizes="(max-width: 768px) 50vw, 33vw"
                  />
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      {images.length === 0 && !isLoading && (
        <div className="text-center py-8 text-gray-500">
          {query ? "No se encontraron imágenes. Intenta con otra búsqueda." : "Busca imágenes para tu producto."}
        </div>
      )}
    </div>
  )
}
