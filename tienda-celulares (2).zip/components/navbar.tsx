"use client"

import Link from "next/link"
import { useState, useEffect } from "react"
import { usePathname, useRouter } from "next/navigation"
import { Search, ShoppingCart, Menu, X, User, LogOut } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"
import { cn } from "@/lib/utils"
import { supabaseClient } from "@/lib/supabase"

export function Navbar() {
  const [isMenuOpen, setIsMenuOpen] = useState(false)
  const [user, setUser] = useState<any>(null)
  const [isAdmin, setIsAdmin] = useState(false)
  const pathname = usePathname()
  const router = useRouter()

  const isAdminPage = pathname.startsWith("/admin")

  useEffect(() => {
    // Verificar si hay un usuario autenticado
    const checkUser = async () => {
      const { data } = await supabaseClient.auth.getUser()
      if (data.user) {
        setUser(data.user)

        // Verificar si el usuario es administrador
        const { data: profileData } = await supabaseClient
          .from("profiles")
          .select("is_admin")
          .eq("id", data.user.id)
          .single()

        if (profileData && profileData.is_admin) {
          setIsAdmin(true)
        }
      }
    }

    checkUser()
  }, [])

  const handleLogout = async () => {
    await supabaseClient.auth.signOut()
    setUser(null)
    setIsAdmin(false)
    router.push("/")
    router.refresh()
  }

  const navLinks = [
    { name: "Inicio", href: "/" },
    { name: "Smartphones", href: "/categoria/smartphones" },
    { name: "Tablets", href: "/categoria/tablets" },
    { name: "Accesorios", href: "/categoria/accesorios" },
    { name: "Ofertas", href: "/ofertas" },
  ]

  return (
    <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
      <div className="container flex h-16 items-center">
        <div className="mr-4 hidden md:flex">
          <Link href="/" className="mr-6 flex items-center space-x-2">
            <span className="font-bold text-xl">TechStore</span>
          </Link>
          <nav className="flex items-center space-x-6 text-sm font-medium">
            {navLinks.map((link) => (
              <Link
                key={link.href}
                href={link.href}
                className={cn(
                  "transition-colors hover:text-foreground/80",
                  pathname === link.href ? "text-foreground font-bold" : "text-foreground/60",
                )}
              >
                {link.name}
              </Link>
            ))}
            {isAdmin && !isAdminPage && (
              <Link href="/admin" className="text-foreground/60 transition-colors hover:text-foreground/80">
                Admin
              </Link>
            )}
          </nav>
        </div>

        <button
          className="inline-flex items-center justify-center rounded-md p-2 text-foreground md:hidden"
          onClick={() => setIsMenuOpen(!isMenuOpen)}
        >
          {isMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
          <span className="sr-only">Toggle Menu</span>
        </button>

        <Link href="/" className="mr-auto md:hidden">
          <span className="font-bold text-xl">TechStore</span>
        </Link>

        {!isAdminPage && (
          <div className="flex flex-1 items-center justify-end space-x-4">
            <div className="w-full max-w-sm hidden md:flex items-center">
              <Input type="search" placeholder="Buscar productos..." className="rounded-r-none focus-visible:ring-0" />
              <Button variant="default" size="icon" className="rounded-l-none">
                <Search className="h-4 w-4" />
                <span className="sr-only">Buscar</span>
              </Button>
            </div>
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="outline" size="icon">
                  <User className="h-4 w-4" />
                  <span className="sr-only">Mi cuenta</span>
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                {user ? (
                  <>
                    <DropdownMenuItem>
                      <Link href="/mi-cuenta" className="w-full">
                        Mi cuenta
                      </Link>
                    </DropdownMenuItem>
                    <DropdownMenuItem>
                      <Link href="/mis-pedidos" className="w-full">
                        Mis pedidos
                      </Link>
                    </DropdownMenuItem>
                    {isAdmin && (
                      <DropdownMenuItem>
                        <Link href="/admin" className="w-full">
                          Panel de administración
                        </Link>
                      </DropdownMenuItem>
                    )}
                    <DropdownMenuItem onClick={handleLogout}>
                      <LogOut className="h-4 w-4 mr-2" />
                      Cerrar sesión
                    </DropdownMenuItem>
                  </>
                ) : (
                  <>
                    <DropdownMenuItem>
                      <Link href="/login" className="w-full">
                        Iniciar sesión
                      </Link>
                    </DropdownMenuItem>
                    <DropdownMenuItem>
                      <Link href="/register" className="w-full">
                        Registrarse
                      </Link>
                    </DropdownMenuItem>
                  </>
                )}
              </DropdownMenuContent>
            </DropdownMenu>
            <Button variant="outline" size="icon">
              <ShoppingCart className="h-4 w-4" />
              <span className="sr-only">Carrito</span>
            </Button>
          </div>
        )}
      </div>

      {isMenuOpen && (
        <div className="container pb-3 md:hidden">
          <nav className="flex flex-col space-y-3">
            {navLinks.map((link) => (
              <Link
                key={link.href}
                href={link.href}
                className={cn(
                  "transition-colors hover:text-foreground/80",
                  pathname === link.href ? "text-foreground font-bold" : "text-foreground/60",
                )}
                onClick={() => setIsMenuOpen(false)}
              >
                {link.name}
              </Link>
            ))}
            {isAdmin && !isAdminPage && (
              <Link
                href="/admin"
                className="text-foreground/60 transition-colors hover:text-foreground/80"
                onClick={() => setIsMenuOpen(false)}
              >
                Admin
              </Link>
            )}
            <div className="pt-2 flex items-center">
              <Input type="search" placeholder="Buscar productos..." className="rounded-r-none focus-visible:ring-0" />
              <Button variant="default" size="icon" className="rounded-l-none">
                <Search className="h-4 w-4" />
                <span className="sr-only">Buscar</span>
              </Button>
            </div>
          </nav>
        </div>
      )}
    </header>
  )
}
