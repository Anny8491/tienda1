from app import app, db, User, Category, Product
from werkzeug.security import generate_password_hash
import os

# Crear directorio para uploads si no existe
os.makedirs('static/uploads', exist_ok=True)

# Inicializar la base de datos
with app.app_context():
    db.create_all()
    
    # Verificar si ya hay datos
    if User.query.count() == 0:
        # Crear usuario administrador
        admin = User(
            email='admin@example.com',
            password=generate_password_hash('admin123', method='sha256'),
            full_name='Administrador',
            is_admin=True
        )
        db.session.add(admin)
        
        # Crear categorías
        categories = [
            {'name': 'Smartphones', 'slug': 'smartphones'},
            {'name': 'Tablets', 'slug': 'tablets'},
            {'name': 'Accesorios', 'slug': 'accesorios'},
            {'name': 'Smartwatches', 'slug': 'smartwatches'},
            {'name': 'Audio', 'slug': 'audio'}
        ]
        
        for category_data in categories:
            category = Category(name=category_data['name'], slug=category_data['slug'])
            db.session.add(category)
        
        db.session.commit()
        
        # Obtener IDs de categorías
        smartphones = Category.query.filter_by(slug='smartphones').first()
        tablets = Category.query.filter_by(slug='tablets').first()
        accesorios = Category.query.filter_by(slug='accesorios').first()
        
        # Crear productos de ejemplo
        products = [
            {
                'name': 'iPhone 13 Pro Max',
                'slug': 'iphone-13-pro-max',
                'description': 'El iPhone 13 Pro Max es el smartphone más avanzado de Apple con una pantalla Super Retina XDR de 6.7 pulgadas.',
                'price': 4999900,
                'stock': 15,
                'category_id': smartphones.id,
                'featured': True,
                'discount_percentage': 0,
                'image_url': '/static/uploads/iphone13promax.jpg'
            },
            {
                'name': 'Samsung Galaxy S21 Ultra',
                'slug': 'samsung-galaxy-s21-ultra',
                'description': 'El Galaxy S21 Ultra 5G está diseñado para que puedas fotografiar o filmar contenido de calidad profesional sin esfuerzo.',
                'price': 4299900,
                'stock': 10,
                'category_id': smartphones.id,
                'featured': True,
                'discount_percentage': 15,
                'image_url': '/static/uploads/s21ultra.jpg'
            },
            {
                'name': 'iPad Pro 12.9"',
                'slug': 'ipad-pro-12-9',
                'description': 'El iPad Pro incluye el chip M1 de Apple para un rendimiento de siguiente nivel y una batería que dura todo el día.',
                'price': 3999900,
                'stock': 8,
                'category_id': tablets.id,
                'featured': True,
                'discount_percentage': 0,
                'image_url': '/static/uploads/ipadpro.jpg'
            },
            {
                'name': 'AirPods Pro',
                'slug': 'airpods-pro',
                'description': 'Los AirPods Pro son los únicos auriculares intraurales con cancelación activa de ruido que se adaptan continuamente a tu oído.',
                'price': 999900,
                'stock': 20,
                'category_id': accesorios.id,
                'featured': False,
                'discount_percentage': 10,
                'image_url': '/static/uploads/airpodspro.jpg'
            }
        ]
        
        for product_data in products:
            product = Product(**product_data)
            db.session.add(product)
        
        db.session.commit()
        
        print("Base de datos inicializada con datos de ejemplo.")
    else:
        print("La base de datos ya contiene datos. No se realizaron cambios.")
