import Image from "next/image"
import Link from "next/link"
import { notFound } from "next/navigation"
import { ShoppingCart, ChevronLeft, Star } from "lucide-react"
import { supabaseAdmin } from "@/lib/supabase"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { formatPrice, calculateDiscountedPrice } from "@/lib/utils"
import { ProductCard } from "@/components/product-card"

async function getProductBySlug(slug: string) {
  const { data, error } = await supabaseAdmin
    .from("products")
    .select("*, category:categories(name, slug)")
    .eq("slug", slug)
    .single()

  if (error) {
    console.error("Error fetching product:", error)
    return null
  }

  return data
}

async function getRelatedProducts(categoryId: number, currentProductId: number) {
  const { data, error } = await supabaseAdmin
    .from("products")
    .select("*, category:categories(name, slug)")
    .eq("category_id", categoryId)
    .neq("id", currentProductId)
    .limit(4)

  if (error) {
    console.error("Error fetching related products:", error)
    return []
  }

  return data
}

export default async function ProductPage({ params }: { params: { slug: string } }) {
  const product = await getProductBySlug(params.slug)

  if (!product) {
    notFound()
  }

  const relatedProducts = await getRelatedProducts(product.category_id, product.id)

  const hasDiscount = product.discount_percentage > 0
  const finalPrice = hasDiscount ? calculateDiscountedPrice(product.price, product.discount_percentage) : product.price

  return (
    <div className="container py-8">
      <div className="mb-6">
        <Link href="/" className="flex items-center text-blue-600 hover:text-blue-800">
          <ChevronLeft className="h-4 w-4 mr-1" />
          Volver a la tienda
        </Link>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-12">
        <div className="relative aspect-square bg-gray-100 rounded-lg overflow-hidden">
          {product.image_url ? (
            <Image
              src={product.image_url || "/placeholder.svg"}
              alt={product.name}
              fill
              sizes="(max-width: 768px) 100vw, 50vw"
              className="object-cover"
            />
          ) : (
            <div className="w-full h-full flex items-center justify-center bg-gray-200">
              <span className="text-gray-400">Sin imagen</span>
            </div>
          )}
          {product.featured && (
            <Badge className="absolute top-4 left-4 bg-yellow-500 hover:bg-yellow-600">Destacado</Badge>
          )}
          {hasDiscount && (
            <Badge className="absolute top-4 right-4 bg-red-500 hover:bg-red-600">
              {product.discount_percentage}% OFF
            </Badge>
          )}
        </div>

        <div>
          <h1 className="text-3xl font-bold mb-2">{product.name}</h1>

          <div className="flex items-center mb-4">
            <div className="flex">
              {[...Array(5)].map((_, i) => (
                <Star key={i} className="h-5 w-5 text-yellow-400 fill-yellow-400" />
              ))}
            </div>
            <span className="ml-2 text-gray-500">(24 reseñas)</span>
          </div>

          <div className="mb-4">
            {hasDiscount ? (
              <div className="flex items-center gap-2">
                <span className="text-3xl font-bold text-blue-600">{formatPrice(finalPrice)}</span>
                <span className="text-xl text-gray-500 line-through">{formatPrice(product.price)}</span>
                <Badge className="bg-red-500 hover:bg-red-600 ml-2">{product.discount_percentage}% OFF</Badge>
              </div>
            ) : (
              <span className="text-3xl font-bold text-blue-600">{formatPrice(product.price)}</span>
            )}
          </div>

          <div className="mb-6">
            <p className="text-gray-700">{product.description}</p>
          </div>

          <div className="mb-6">
            <div className="flex items-center mb-2">
              <div className="w-4 h-4 rounded-full bg-green-500 mr-2"></div>
              <span className="text-green-600 font-medium">
                {product.stock > 0 ? `En stock (${product.stock} disponibles)` : "Agotado"}
              </span>
            </div>
            <div className="text-sm text-gray-500">Envío gratis en compras superiores a $200.000</div>
          </div>

          <div className="flex flex-col sm:flex-row gap-4">
            <Button size="lg" className="flex-1" disabled={product.stock === 0}>
              <ShoppingCart className="mr-2 h-5 w-5" />
              Añadir al carrito
            </Button>
            <Button size="lg" variant="outline" className="flex-1">
              Comprar ahora
            </Button>
          </div>
        </div>
      </div>

      <Tabs defaultValue="description" className="mb-12">
        <TabsList>
          <TabsTrigger value="description">Descripción</TabsTrigger>
          <TabsTrigger value="specifications">Especificaciones</TabsTrigger>
          <TabsTrigger value="reviews">Reseñas</TabsTrigger>
        </TabsList>
        <TabsContent value="description" className="p-4">
          <div className="prose max-w-none">
            <p>{product.description || "No hay descripción disponible para este producto."}</p>
          </div>
        </TabsContent>
        <TabsContent value="specifications" className="p-4">
          <div className="prose max-w-none">
            <p>Especificaciones del producto.</p>
            <ul>
              <li>Característica 1</li>
              <li>Característica 2</li>
              <li>Característica 3</li>
            </ul>
          </div>
        </TabsContent>
        <TabsContent value="reviews" className="p-4">
          <div className="prose max-w-none">
            <p>Reseñas de clientes.</p>
          </div>
        </TabsContent>
      </Tabs>

      {relatedProducts.length > 0 && (
        <section>
          <h2 className="text-2xl font-bold mb-6">Productos relacionados</h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
            {relatedProducts.map((relatedProduct) => (
              <ProductCard key={relatedProduct.id} product={relatedProduct} />
            ))}
          </div>
        </section>
      )}
    </div>
  )
}
