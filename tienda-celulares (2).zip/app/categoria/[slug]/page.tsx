import { notFound } from "next/navigation"
import { supabaseAdmin } from "@/lib/supabase"
import { ProductCard } from "@/components/product-card"

async function getCategoryBySlug(slug: string) {
  const { data, error } = await supabaseAdmin.from("categories").select("*").eq("slug", slug).single()

  if (error) {
    console.error("Error fetching category:", error)
    return null
  }

  return data
}

async function getProductsByCategory(categoryId: number) {
  const { data, error } = await supabaseAdmin
    .from("products")
    .select("*, category:categories(name, slug)")
    .eq("category_id", categoryId)
    .order("created_at", { ascending: false })

  if (error) {
    console.error("Error fetching products by category:", error)
    return []
  }

  return data
}

export default async function CategoryPage({ params }: { params: { slug: string } }) {
  const category = await getCategoryBySlug(params.slug)

  if (!category) {
    notFound()
  }

  const products = await getProductsByCategory(category.id)

  return (
    <div className="container py-8">
      <h1 className="text-3xl font-bold mb-8">{category.name}</h1>

      {products.length === 0 ? (
        <div className="text-center py-12">
          <p className="text-gray-500">No hay productos en esta categoría.</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
          {products.map((product) => (
            <ProductCard key={product.id} product={product} />
          ))}
        </div>
      )}
    </div>
  )
}
