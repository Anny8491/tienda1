import { NextResponse } from "next/server"
import { put } from "@vercel/blob"
import { createServerSupabaseClient } from "@/lib/auth"

export async function POST(request: Request) {
  try {
    // Verificar autenticación
    const supabase = await createServerSupabaseClient()
    const {
      data: { session },
    } = await supabase.auth.getSession()

    if (!session) {
      return NextResponse.json({ error: "No autorizado" }, { status: 401 })
    }

    // Obtener datos de la solicitud
    const data = await request.json()
    const { imageUrl, productId } = data

    if (!imageUrl || !productId) {
      return NextResponse.json({ error: "Se requiere URL de imagen e ID de producto" }, { status: 400 })
    }

    // Descargar la imagen desde la URL
    const imageResponse = await fetch(imageUrl)
    if (!imageResponse.ok) {
      throw new Error(`Error al descargar la imagen: ${imageResponse.statusText}`)
    }

    const imageBlob = await imageResponse.blob()
    const filename = `product-${productId}-${Date.now()}.${imageUrl.split(".").pop()?.split("?")[0] || "jpg"}`

    // Subir la imagen a Vercel Blob
    const blob = await put(filename, imageBlob, {
      access: "public",
    })

    // Actualizar la URL de la imagen en la base de datos
    const { error } = await supabase.from("products").update({ image_url: blob.url }).eq("id", productId)

    if (error) {
      throw error
    }

    return NextResponse.json({ success: true, url: blob.url })
  } catch (error: any) {
    console.error("Error al procesar la imagen:", error)
    return NextResponse.json({ error: error.message || "Error al procesar la imagen" }, { status: 500 })
  }
}
