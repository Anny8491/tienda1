import { NextResponse } from "next/server"

// Esta es una API simple que busca imágenes de productos
// En un entorno real, podrías usar APIs como Unsplash, Pexels, etc.
export async function GET(request: Request) {
  const { searchParams } = new URL(request.url)
  const query = searchParams.get("query")

  if (!query) {
    return NextResponse.json({ error: "Se requiere un término de búsqueda" }, { status: 400 })
  }

  try {
    // Aquí podrías integrar con una API real de imágenes
    // Por ahora, usaremos una lista de imágenes de ejemplo
    const images = [
      {
        id: "1",
        url: "https://images.unsplash.com/photo-1511707171634-5f897ff02aa9?w=500&q=80",
        alt: "Smartphone moderno",
      },
      {
        id: "2",
        url: "https://images.unsplash.com/photo-1592899677977-9c10ca588bbd?w=500&q=80",
        alt: "Teléfono con apps",
      },
      {
        id: "3",
        url: "https://images.unsplash.com/photo-1546054454-aa26e2b734c7?w=500&q=80",
        alt: "Smartphone con funda",
      },
      {
        id: "4",
        url: "https://images.unsplash.com/photo-1551721434-8b94ddff0e6d?w=500&q=80",
        alt: "Accesorios para teléfono",
      },
      {
        id: "5",
        url: "https://images.unsplash.com/photo-1574944985070-8f3ebc6b79d2?w=500&q=80",
        alt: "Auriculares inalámbricos",
      },
    ]

    // Filtrar imágenes basadas en la consulta (en un caso real, esto lo haría la API)
    const filteredImages = images.filter((image) => image.alt.toLowerCase().includes(query.toLowerCase()))

    return NextResponse.json({ images: filteredImages })
  } catch (error) {
    console.error("Error al buscar imágenes:", error)
    return NextResponse.json({ error: "Error al buscar imágenes" }, { status: 500 })
  }
}
