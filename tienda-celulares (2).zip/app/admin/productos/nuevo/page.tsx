"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import Image from "next/image"
import { supabaseClient } from "@/lib/supabase"
import { generateSlug } from "@/lib/utils"
import { uploadProductImage } from "@/lib/blob"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Checkbox } from "@/components/ui/checkbox"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { ImageSearch } from "@/components/image-search"
import { useToast } from "@/hooks/use-toast"

export default function NewProductPage() {
  const router = useRouter()
  const { toast } = useToast()
  const [isLoading, setIsLoading] = useState(false)
  const [categories, setCategories] = useState([])
  const [formData, setFormData] = useState({
    name: "",
    description: "",
    price: "",
    stock: "",
    category_id: "",
    featured: false,
    discount_percentage: "",
  })
  const [imageFile, setImageFile] = useState<File | null>(null)
  const [imagePreview, setImagePreview] = useState<string | null>(null)
  const [selectedImageUrl, setSelectedImageUrl] = useState<string | null>(null)
  const [activeTab, setActiveTab] = useState<string>("upload")

  // Cargar categorías al montar el componente
  useEffect(() => {
    const fetchCategories = async () => {
      const { data } = await supabaseClient.from("categories").select("*")
      if (data) setCategories(data)
    }
    fetchCategories()
  }, [])

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target
    setFormData((prev) => ({ ...prev, [name]: value }))
  }

  const handleSelectChange = (name: string, value: string) => {
    setFormData((prev) => ({ ...prev, [name]: value }))
  }

  const handleCheckboxChange = (name: string, checked: boolean) => {
    setFormData((prev) => ({ ...prev, [name]: checked }))
  }

  const handleImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0]
      setImageFile(file)

      // Crear una vista previa de la imagen
      const reader = new FileReader()
      reader.onload = () => {
        setImagePreview(reader.result as string)
      }
      reader.readAsDataURL(file)
    }
  }

  const handleSelectImageFromSearch = (imageUrl: string) => {
    setSelectedImageUrl(imageUrl)
    setImagePreview(imageUrl)
    setImageFile(null) // Limpiar el archivo de imagen si se selecciona una imagen de la búsqueda
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsLoading(true)

    try {
      // Crear el slug a partir del nombre
      const slug = generateSlug(formData.name)

      // Insertar el producto en la base de datos
      const { data, error } = await supabaseClient
        .from("products")
        .insert({
          name: formData.name,
          slug,
          description: formData.description,
          price: Number.parseFloat(formData.price),
          stock: Number.parseInt(formData.stock),
          category_id: formData.category_id ? Number.parseInt(formData.category_id) : null,
          featured: formData.featured,
          discount_percentage: formData.discount_percentage ? Number.parseInt(formData.discount_percentage) : 0,
        })
        .select()

      if (error) throw error

      if (data && data[0]) {
        const productId = data[0].id

        // Si hay una imagen seleccionada de la búsqueda
        if (selectedImageUrl && activeTab === "search") {
          const downloadResponse = await fetch("/api/images/download", {
            method: "POST",
            headers: {
              "Content-Type": "application/json",
            },
            body: JSON.stringify({
              imageUrl: selectedImageUrl,
              productId: productId,
            }),
          })

          const downloadResult = await downloadResponse.json()

          if (!downloadResult.success) {
            throw new Error("Error al descargar la imagen")
          }
        }
        // Si hay un archivo de imagen subido
        else if (imageFile && activeTab === "upload") {
          // Crear un FormData para subir la imagen
          const imageFormData = new FormData()
          imageFormData.append("image", imageFile)
          imageFormData.append("productId", productId.toString())

          // Subir la imagen
          const uploadResult = await uploadProductImage(imageFormData)

          if (!uploadResult.success) {
            throw new Error("Error al subir la imagen")
          }
        }
      }

      toast({
        title: "Producto creado",
        description: "El producto se ha creado correctamente",
      })

      // Redireccionar a la lista de productos
      router.push("/admin/productos")
      router.refresh()
    } catch (error: any) {
      console.error("Error al crear el producto:", error)
      toast({
        title: "Error",
        description: error.message || "Ha ocurrido un error al crear el producto",
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <div>
      <h1 className="text-2xl font-bold mb-6">Nuevo Producto</h1>

      <form onSubmit={handleSubmit}>
        <Card>
          <CardHeader>
            <CardTitle>Información del producto</CardTitle>
            <CardDescription>Ingresa los detalles del nuevo producto</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="name">Nombre</Label>
                <Input id="name" name="name" value={formData.name} onChange={handleChange} required />
              </div>

              <div className="space-y-2">
                <Label htmlFor="category">Categoría</Label>
                <Select
                  value={formData.category_id}
                  onValueChange={(value) => handleSelectChange("category_id", value)}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Seleccionar categoría" />
                  </SelectTrigger>
                  <SelectContent>
                    {categories.map((category: any) => (
                      <SelectItem key={category.id} value={category.id.toString()}>
                        {category.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="price">Precio</Label>
                <Input id="price" name="price" type="number" value={formData.price} onChange={handleChange} required />
              </div>

              <div className="space-y-2">
                <Label htmlFor="stock">Stock</Label>
                <Input id="stock" name="stock" type="number" value={formData.stock} onChange={handleChange} required />
              </div>

              <div className="space-y-2">
                <Label htmlFor="discount_percentage">Porcentaje de descuento</Label>
                <Input
                  id="discount_percentage"
                  name="discount_percentage"
                  type="number"
                  min="0"
                  max="100"
                  value={formData.discount_percentage}
                  onChange={handleChange}
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="description">Descripción</Label>
              <Textarea
                id="description"
                name="description"
                value={formData.description}
                onChange={handleChange}
                rows={4}
              />
            </div>

            <div className="flex items-center space-x-2">
              <Checkbox
                id="featured"
                checked={formData.featured}
                onCheckedChange={(checked) => handleCheckboxChange("featured", checked as boolean)}
              />
              <Label htmlFor="featured">Destacado</Label>
            </div>

            <div className="space-y-2">
              <Label>Imagen del producto</Label>
              <Tabs defaultValue="upload" onValueChange={setActiveTab}>
                <TabsList className="grid w-full grid-cols-2">
                  <TabsTrigger value="upload">Subir imagen</TabsTrigger>
                  <TabsTrigger value="search">Buscar imagen</TabsTrigger>
                </TabsList>
                <TabsContent value="upload" className="space-y-4">
                  <Input id="image" name="image" type="file" accept="image/*" onChange={handleImageChange} />
                  {imagePreview && activeTab === "upload" && (
                    <div className="mt-2 relative w-40 h-40 border rounded overflow-hidden">
                      <Image
                        src={imagePreview || "/placeholder.svg"}
                        alt="Vista previa"
                        fill
                        className="object-cover"
                      />
                    </div>
                  )}
                </TabsContent>
                <TabsContent value="search" className="space-y-4">
                  <ImageSearch onSelectImage={handleSelectImageFromSearch} productName={formData.name} />
                  {imagePreview && activeTab === "search" && (
                    <div className="mt-2 relative w-40 h-40 border rounded overflow-hidden">
                      <Image
                        src={imagePreview || "/placeholder.svg"}
                        alt="Vista previa"
                        fill
                        className="object-cover"
                      />
                    </div>
                  )}
                </TabsContent>
              </Tabs>
            </div>
          </CardContent>
          <CardFooter className="flex justify-between">
            <Button type="button" variant="outline" onClick={() => router.back()} disabled={isLoading}>
              Cancelar
            </Button>
            <Button type="submit" disabled={isLoading}>
              {isLoading ? "Guardando..." : "Guardar producto"}
            </Button>
          </CardFooter>
        </Card>
      </form>
    </div>
  )
}
