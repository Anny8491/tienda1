"use client"

import type React from "react"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import Image from "next/image"
import { supabaseClient } from "@/lib/supabase"
import { uploadProductImage } from "@/lib/blob"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Checkbox } from "@/components/ui/checkbox"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { ImageSearch } from "@/components/image-search"
import { useToast } from "@/hooks/use-toast"
import type { Product } from "@/lib/supabase"

export default function EditProductPage({ params }: { params: { id: string } }) {
  const router = useRouter()
  const { toast } = useToast()
  const [isLoading, setIsLoading] = useState(false)
  const [isSaving, setIsSaving] = useState(false)
  const [categories, setCategories] = useState([])
  const [product, setProduct] = useState<Product | null>(null)
  const [formData, setFormData] = useState({
    name: "",
    description: "",
    price: "",
    stock: "",
    category_id: "",
    featured: false,
    discount_percentage: "",
  })
  const [imageFile, setImageFile] = useState<File | null>(null)
  const [imagePreview, setImagePreview] = useState<string | null>(null)
  const [selectedImageUrl, setSelectedImageUrl] = useState<string | null>(null)
  const [activeTab, setActiveTab] = useState<string>("upload")

  // Cargar producto y categorías al montar el componente
  useEffect(() => {
    const fetchData = async () => {
      setIsLoading(true)
      try {
        // Cargar categorías
        const { data: categoriesData } = await supabaseClient.from("categories").select("*")
        if (categoriesData) setCategories(categoriesData)

        // Cargar producto
        const { data: productData, error } = await supabaseClient
          .from("products")
          .select("*")
          .eq("id", params.id)
          .single()

        if (error) throw error

        if (productData) {
          setProduct(productData)
          setFormData({
            name: productData.name,
            description: productData.description || "",
            price: productData.price.toString(),
            stock: productData.stock.toString(),
            category_id: productData.category_id ? productData.category_id.toString() : "",
            featured: productData.featured,
            discount_percentage: productData.discount_percentage ? productData.discount_percentage.toString() : "",
          })

          if (productData.image_url) {
            setImagePreview(productData.image_url)
          }
        }
      } catch (error) {
        console.error("Error al cargar datos:", error)
        toast({
          title: "Error",
          description: "No se pudo cargar la información del producto",
          variant: "destructive",
        })
      } finally {
        setIsLoading(false)
      }
    }

    fetchData()
  }, [params.id, toast])

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target
    setFormData((prev) => ({ ...prev, [name]: value }))
  }

  const handleSelectChange = (name: string, value: string) => {
    setFormData((prev) => ({ ...prev, [name]: value }))
  }

  const handleCheckboxChange = (name: string, checked: boolean) => {
    setFormData((prev) => ({ ...prev, [name]: checked }))
  }

  const handleImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0]
      setImageFile(file)

      // Crear una vista previa de la imagen
      const reader = new FileReader()
      reader.onload = () => {
        setImagePreview(reader.result as string)
      }
      reader.readAsDataURL(file)
    }
  }

  const handleSelectImageFromSearch = (imageUrl: string) => {
    setSelectedImageUrl(imageUrl)
    setImagePreview(imageUrl)
    setImageFile(null) // Limpiar el archivo de imagen si se selecciona una imagen de la búsqueda
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsSaving(true)

    try {
      // Actualizar el producto en la base de datos
      const { error } = await supabaseClient
        .from("products")
        .update({
          name: formData.name,
          description: formData.description,
          price: Number.parseFloat(formData.price),
          stock: Number.parseInt(formData.stock),
          category_id: formData.category_id ? Number.parseInt(formData.category_id) : null,
          featured: formData.featured,
          discount_percentage: formData.discount_percentage ? Number.parseInt(formData.discount_percentage) : 0,
          updated_at: new Date().toISOString(),
        })
        .eq("id", params.id)

      if (error) throw error

      // Si hay una imagen seleccionada de la búsqueda
      if (selectedImageUrl && activeTab === "search") {
        const downloadResponse = await fetch("/api/images/download", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({
            imageUrl: selectedImageUrl,
            productId: params.id,
          }),
        })

        const downloadResult = await downloadResponse.json()

        if (!downloadResult.success) {
          throw new Error("Error al descargar la imagen")
        }
      }
      // Si hay un archivo de imagen subido
      else if (imageFile && activeTab === "upload") {
        // Crear un FormData para subir la imagen
        const imageFormData = new FormData()
        imageFormData.append("image", imageFile)
        imageFormData.append("productId", params.id)

        // Subir la imagen
        const uploadResult = await uploadProductImage(imageFormData)

        if (!uploadResult.success) {
          throw new Error("Error al subir la imagen")
        }
      }

      toast({
        title: "Producto actualizado",
        description: "El producto se ha actualizado correctamente",
      })

      // Redireccionar a la lista de productos
      router.push("/admin/productos")
      router.refresh()
    } catch (error: any) {
      console.error("Error al actualizar el producto:", error)
      toast({
        title: "Error",
        description: error.message || "Ha ocurrido un error al actualizar el producto",
        variant: "destructive",
      })
    } finally {
      setIsSaving(false)
    }
  }

  const handleDelete = async () => {
    if (!confirm("¿Estás seguro de que deseas eliminar este producto?")) return

    setIsLoading(true)

    try {
      const { error } = await supabaseClient.from("products").delete().eq("id", params.id)

      if (error) throw error

      toast({
        title: "Producto eliminado",
        description: "El producto se ha eliminado correctamente",
      })

      router.push("/admin/productos")
      router.refresh()
    } catch (error: any) {
      console.error("Error al eliminar el producto:", error)
      toast({
        title: "Error",
        description: error.message || "Ha ocurrido un error al eliminar el producto",
        variant: "destructive",
      })
    } finally {
      setIsLoading(false)
    }
  }

  if (isLoading) {
    return <div>Cargando...</div>
  }

  return (
    <div>
      <h1 className="text-2xl font-bold mb-6">Editar Producto</h1>

      <form onSubmit={handleSubmit}>
        <Card>
          <CardHeader>
            <CardTitle>Información del producto</CardTitle>
            <CardDescription>Actualiza los detalles del producto</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="name">Nombre</Label>
                <Input id="name" name="name" value={formData.name} onChange={handleChange} required />
              </div>

              <div className="space-y-2">
                <Label htmlFor="category">Categoría</Label>
                <Select
                  value={formData.category_id}
                  onValueChange={(value) => handleSelectChange("category_id", value)}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Seleccionar categoría" />
                  </SelectTrigger>
                  <SelectContent>
                    {categories.map((category: any) => (
                      <SelectItem key={category.id} value={category.id.toString()}>
                        {category.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="price">Precio</Label>
                <Input id="price" name="price" type="number" value={formData.price} onChange={handleChange} required />
              </div>

              <div className="space-y-2">
                <Label htmlFor="stock">Stock</Label>
                <Input id="stock" name="stock" type="number" value={formData.stock} onChange={handleChange} required />
              </div>

              <div className="space-y-2">
                <Label htmlFor="discount_percentage">Porcentaje de descuento</Label>
                <Input
                  id="discount_percentage"
                  name="discount_percentage"
                  type="number"
                  min="0"
                  max="100"
                  value={formData.discount_percentage}
                  onChange={handleChange}
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="description">Descripción</Label>
              <Textarea
                id="description"
                name="description"
                value={formData.description}
                onChange={handleChange}
                rows={4}
              />
            </div>

            <div className="flex items-center space-x-2">
              <Checkbox
                id="featured"
                checked={formData.featured}
                onCheckedChange={(checked) => handleCheckboxChange("featured", checked as boolean)}
              />
              <Label htmlFor="featured">Destacado</Label>
            </div>

            <div className="space-y-2">
              <Label>Imagen del producto</Label>
              <Tabs defaultValue="upload" onValueChange={setActiveTab}>
                <TabsList className="grid w-full grid-cols-2">
                  <TabsTrigger value="upload">Subir imagen</TabsTrigger>
                  <TabsTrigger value="search">Buscar imagen</TabsTrigger>
                </TabsList>
                <TabsContent value="upload" className="space-y-4">
                  <Input id="image" name="image" type="file" accept="image/*" onChange={handleImageChange} />
                  {imagePreview && activeTab === "upload" && (
                    <div className="mt-2 relative w-40 h-40 border rounded overflow-hidden">
                      <Image
                        src={imagePreview || "/placeholder.svg"}
                        alt="Vista previa"
                        fill
                        className="object-cover"
                      />
                    </div>
                  )}
                </TabsContent>
                <TabsContent value="search" className="space-y-4">
                  <ImageSearch onSelectImage={handleSelectImageFromSearch} productName={formData.name} />
                  {imagePreview && activeTab === "search" && (
                    <div className="mt-2 relative w-40 h-40 border rounded overflow-hidden">
                      <Image
                        src={imagePreview || "/placeholder.svg"}
                        alt="Vista previa"
                        fill
                        className="object-cover"
                      />
                    </div>
                  )}
                </TabsContent>
              </Tabs>
            </div>
          </CardContent>
          <CardFooter className="flex justify-between">
            <div>
              <Button type="button" variant="destructive" onClick={handleDelete} disabled={isLoading || isSaving}>
                Eliminar
              </Button>
            </div>
            <div className="flex space-x-2">
              <Button type="button" variant="outline" onClick={() => router.back()} disabled={isLoading || isSaving}>
                Cancelar
              </Button>
              <Button type="submit" disabled={isLoading || isSaving}>
                {isSaving ? "Guardando..." : "Guardar cambios"}
              </Button>
            </div>
          </CardFooter>
        </Card>
      </form>
    </div>
  )
}
