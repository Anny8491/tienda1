import { supabaseAdmin } from "@/lib/supabase"
import { ProductCard } from "@/components/product-card"

async function getDiscountedProducts() {
  const { data, error } = await supabaseAdmin
    .from("products")
    .select("*, category:categories(name, slug)")
    .gt("discount_percentage", 0)
    .order("discount_percentage", { ascending: false })

  if (error) {
    console.error("Error fetching discounted products:", error)
    return []
  }

  return data
}

export default async function OffersPage() {
  const products = await getDiscountedProducts()

  return (
    <div className="container py-8">
      <div className="bg-gradient-to-r from-red-600 to-orange-600 text-white rounded-lg p-8 mb-8">
        <div className="max-w-3xl mx-auto text-center">
          <h1 className="text-3xl md:text-4xl font-bold mb-4">Ofertas Especiales</h1>
          <p className="text-lg mb-0">
            Descubre nuestras mejores ofertas con descuentos increíbles en productos seleccionados.
          </p>
        </div>
      </div>

      {products.length === 0 ? (
        <div className="text-center py-12">
          <p className="text-gray-500">No hay productos en oferta actualmente.</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
          {products.map((product) => (
            <ProductCard key={product.id} product={product} />
          ))}
        </div>
      )}
    </div>
  )
}
