import { Suspense } from "react"
import Link from "next/link"
import { ChevronRight } from "lucide-react"
import { supabaseAdmin } from "@/lib/supabase"
import { HeroBanner } from "@/components/hero-banner"
import { ProductCard } from "@/components/product-card"
import { Button } from "@/components/ui/button"

async function getFeaturedProducts() {
  const { data, error } = await supabaseAdmin
    .from("products")
    .select("*, category:categories(name, slug)")
    .eq("featured", true)
    .order("created_at", { ascending: false })
    .limit(4)

  if (error) {
    console.error("Error fetching featured products:", error)
    return []
  }

  return data
}

async function getDiscountedProducts() {
  const { data, error } = await supabaseAdmin
    .from("products")
    .select("*, category:categories(name, slug)")
    .gt("discount_percentage", 0)
    .order("discount_percentage", { ascending: false })
    .limit(4)

  if (error) {
    console.error("Error fetching discounted products:", error)
    return []
  }

  return data
}

async function getCategories() {
  const { data, error } = await supabaseAdmin.from("categories").select("*")

  if (error) {
    console.error("Error fetching categories:", error)
    return []
  }

  return data
}

export default async function Home() {
  const [featuredProducts, discountedProducts, categories] = await Promise.all([
    getFeaturedProducts(),
    getDiscountedProducts(),
    getCategories(),
  ])

  return (
    <div className="flex flex-col min-h-screen">
      <HeroBanner />

      <section className="container py-12">
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-2xl font-bold">Categorías</h2>
        </div>
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-4">
          {categories.map((category) => (
            <Link
              key={category.id}
              href={`/categoria/${category.slug}`}
              className="bg-gray-100 hover:bg-gray-200 rounded-lg p-6 text-center transition-colors"
            >
              <h3 className="font-medium">{category.name}</h3>
            </Link>
          ))}
        </div>
      </section>

      <section className="container py-12">
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-2xl font-bold">Productos destacados</h2>
          <Button asChild variant="ghost" className="gap-1">
            <Link href="/destacados">
              Ver todos <ChevronRight className="h-4 w-4" />
            </Link>
          </Button>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
          <Suspense fallback={<p>Cargando productos destacados...</p>}>
            {featuredProducts.map((product) => (
              <ProductCard key={product.id} product={product} />
            ))}
          </Suspense>
        </div>
      </section>

      <section className="container py-12 bg-gray-50 -mx-4 px-4 sm:mx-0 sm:px-4">
        <div className="flex justify-between items-center mb-6">
          <h2 className="text-2xl font-bold">Ofertas especiales</h2>
          <Button asChild variant="ghost" className="gap-1">
            <Link href="/ofertas">
              Ver todas <ChevronRight className="h-4 w-4" />
            </Link>
          </Button>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
          <Suspense fallback={<p>Cargando ofertas...</p>}>
            {discountedProducts.map((product) => (
              <ProductCard key={product.id} product={product} />
            ))}
          </Suspense>
        </div>
      </section>

      <section className="container py-12">
        <div className="bg-blue-600 rounded-lg p-8 text-white">
          <div className="max-w-3xl mx-auto text-center">
            <h2 className="text-2xl md:text-3xl font-bold mb-4">¿Buscas asesoría personalizada?</h2>
            <p className="text-lg mb-6">
              Nuestro equipo de expertos está listo para ayudarte a encontrar el dispositivo perfecto para ti.
            </p>
            <Button asChild size="lg" className="bg-white text-blue-700 hover:bg-blue-50">
              <Link href="/contacto">Contáctanos ahora</Link>
            </Button>
          </div>
        </div>
      </section>
    </div>
  )
}
